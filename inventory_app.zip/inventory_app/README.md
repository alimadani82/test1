# CafAc Production App

Next.js + Tailwind + shadcn-style UI with Supabase for recipes and production logging, plus optional n8n webhook. Menu items and materials stay local/static.

## Stack
- Next.js (App Router, TypeScript)
- Tailwind CSS
- Zustand, TanStack Query
- react-hook-form + zod
- Supabase (service role, server-only) for `recipes` + `production_log`
- Optional n8n webhook for downstream automations

## Environment
Copy `.env.example` to `.env.local` and set:
- `SUPABASE_URL` � project URL
- `SUPABASE_SERVICE_ROLE_KEY` � service role key (server-only)
- `N8N_WEBHOOK_URL` � optional; POSTed full payload

## Running locally
```bash
npm install
npm run dev
```
Visit http://localhost:3000.

## API behavior
- `GET /api/menu-items` ? `{ items: Product[] }` (local static data)
- `GET /api/materials` ? `{ materials: Material[] }` (local static data)
- `GET /api/recipes?productId=...` ? `{ recipes: RecipeRow[] }` (Supabase `recipes`)
- `POST /api/production` ? validates payload, writes one row per consumed material into Supabase `production_log`, and POSTs payload to `N8N_WEBHOOK_URL` if set. `batch_id` groups rows for one submission.
#   i n v e n t o r y 1  
 #   i n v e n t o r y 1  
 